'use strict';
(function(){
  var API = 'https://faset.xo.je/api/check.php';
  var DEVICE_KEY = 'fbpx_device_id';
  var DEVICE_LABEL_KEY = 'fbpx_device_label';
  function redirectOut(){ window.location.href = chrome.runtime.getURL('popup.html'); }
  function randomId(){
    try { if (crypto && crypto.randomUUID) return 'dev-' + crypto.randomUUID().replace(/-/g,'').slice(0,24); } catch(e){}
    return 'dev-' + Date.now().toString(36) + Math.random().toString(36).slice(2,10);
  }
  function ensureDevice(cb){
    chrome.storage.local.get([DEVICE_KEY, DEVICE_LABEL_KEY], function(r){
      var deviceId = r[DEVICE_KEY] || ''; if (!deviceId) { deviceId = randomId(); }
      var deviceLabel = r[DEVICE_LABEL_KEY] || 'Kiwi Android';
      var patch = {}; patch[DEVICE_KEY] = deviceId; patch[DEVICE_LABEL_KEY] = deviceLabel;
      chrome.storage.local.set(patch, function(){ cb(deviceId, deviceLabel); });
    });
  }
  function showMessage(msg){
    var div = document.createElement('div');
    div.style.cssText = 'position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#08101d;color:#eef2ff;z-index:999999;font-family:Cairo,Tahoma,sans-serif;padding:24px;text-align:center';
    div.innerHTML = '<div><div style="font-size:22px;font-weight:800;margin-bottom:8px">الوصول مقفول</div><div style="color:#a8b4d4;line-height:1.7">'+ msg +'</div></div>';
    document.body.appendChild(div);
  }
  document.addEventListener('DOMContentLoaded', function(){
    chrome.storage.local.get(['fbpx_lp_email','fbpx_lp_token'], function(r){
      if (!r.fbpx_lp_email || !r.fbpx_lp_token) { redirectOut(); return; }
      ensureDevice(function(deviceId, deviceLabel){
        fetch(API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email:r.fbpx_lp_email, token:r.fbpx_lp_token, device_id: deviceId, device_label: deviceLabel, extension_version: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '' }) })
          .then(function(resp){ return resp.json().then(function(data){ return { ok: resp.ok && data.ok, data: data || {} }; }); })
          .then(function(result){
            if (!result.ok || !result.data.access_granted) {
              showMessage('انتهت التجربة أو الاشتراك غير مفعّل. سيتم تحويلك لواجهة الإضافة.');
              setTimeout(redirectOut, 1800);
            }
          })
          .catch(function(){ /* ignore transient network failure */ });
      });
    });
  });
}());
